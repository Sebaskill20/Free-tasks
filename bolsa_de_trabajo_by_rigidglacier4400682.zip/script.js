document.addEventListener('DOMContentLoaded', () => {
  const btnPublicar = document.getElementById('btn-publicar');
  const btnBuscar = document.getElementById('btn-buscar');
  const publicarTareaSection = document.getElementById('publicar-tarea');
  const buscarTareaSection = document.getElementById('buscar-tarea');
  const formPublicar = document.getElementById('form-publicar');
  const tareasContainer = document.getElementById('tareas-container');
  const searchInput = document.getElementById('search-input');
  const resultadosBusqueda = document.getElementById('resultados-busqueda');

  let tareas = [];

  // Funciones para mostrar/ocultar secciones
  function mostrarSeccion(seccion) {
    publicarTareaSection.classList.add('oculto');
    buscarTareaSection.classList.add('oculto');
    seccion.classList.remove('oculto');
  }

  // Event listeners para los botones
  btnPublicar.addEventListener('click', () => mostrarSeccion(publicarTareaSection));
  btnBuscar.addEventListener('click', () => mostrarSeccion(buscarTareaSection));

  // Event listener para el formulario de publicación
  formPublicar.addEventListener('submit', (event) => {
    event.preventDefault();

    const titulo = document.getElementById('titulo').value;
    const descripcion = document.getElementById('descripcion').value;
    const categoria = document.getElementById('categoria').value;
    const ubicacion = document.getElementById('ubicacion').value;
    const contacto = document.getElementById('contacto').value;

    const nuevaTarea = {
      id: Date.now(), // Generar un ID único
      titulo,
      descripcion,
      categoria,
      ubicacion,
      contacto
    };

    tareas.push(nuevaTarea);
    mostrarTareas();

    // Limpiar el formulario
    formPublicar.reset();

    // Ocultar la sección de publicación
    publicarTareaSection.classList.add('oculto');
  });

  // Función para mostrar las tareas en el contenedor
  function mostrarTareas() {
    tareasContainer.innerHTML = ''; // Limpiar el contenedor

    tareas.forEach(tarea => {
      const tareaElement = document.createElement('div');
      tareaElement.classList.add('tarea');
      tareaElement.innerHTML = `
        <h3>${tarea.titulo}</h3>
        <p>${tarea.descripcion}</p>
        <p><strong>Categoría:</strong> ${tarea.categoria}</p>
        <p><strong>Ubicación:</strong> ${tarea.ubicacion}</p>
        <p><strong>Contacto:</strong> <a href="mailto:${tarea.contacto}">${tarea.contacto}</a></p>
      `;
      tareasContainer.appendChild(tareaElement);
    });
  }

  // Event listener para la búsqueda
  searchInput.addEventListener('input', () => {
    const searchTerm = searchInput.value.toLowerCase();
    const resultados = tareas.filter(tarea =>
      tarea.titulo.toLowerCase().includes(searchTerm) ||
      tarea.descripcion.toLowerCase().includes(searchTerm)
    );

    mostrarResultadosBusqueda(resultados);
  });

  // Función para mostrar los resultados de la búsqueda
  function mostrarResultadosBusqueda(resultados) {
    resultadosBusqueda.innerHTML = ''; // Limpiar los resultados

    if (resultados.length === 0) {
      resultadosBusqueda.innerHTML = '<p>No se encontraron resultados.</p>';
      return;
    }

    resultados.forEach(tarea => {
      const resultadoElement = document.createElement('div');
      resultadoElement.classList.add('tarea'); // Reutilizar la clase "tarea"
      resultadoElement.innerHTML = `
        <h3>${tarea.titulo}</h3>
        <p>${tarea.descripcion}</p>
        <p><strong>Categoría:</strong> ${tarea.categoria}</p>
        <p><strong>Ubicación:</strong> ${tarea.ubicacion}</p>
        <p><strong>Contacto:</strong> <a href="mailto:${tarea.contacto}">${tarea.contacto}</a></p>
      `;
      resultadosBusqueda.appendChild(resultadoElement);
    });
  }

  // Mostrar las tareas iniciales (si las hay - puedes cargar desde localStorage aquí)
  mostrarTareas();
});